#include "../include/Caracteristiques.h"

Caracteristiques::Caracteristiques(unsigned x, unsigned y, unsigned hp, unsigned radius, unsigned vit, GRRLIB_texImg* image)
{
    //ctor
}

Caracteristiques::~Caracteristiques()
{
    //dtor
}

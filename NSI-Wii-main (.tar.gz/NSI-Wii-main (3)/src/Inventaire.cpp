#include "../include/Inventaire.h"
/*
Inventaire::Inventaire(int taille, Arme * arme)
{
    m_taille=taille;
    for (int i = 0; i < 5; i++){
        inventaire[i] = NULL;
    }
}

Inventaire::~Inventaire()
{
    //dtor
}
*/

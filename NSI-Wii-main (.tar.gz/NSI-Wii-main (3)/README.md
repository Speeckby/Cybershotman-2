# Survivor.io 2.0
## Objectif
Tuer les ennemis arrivant en vague pour améliorer vos équipements et être préparé aux ennemis suivants
Survivez le plus longtemps possible !

## Contributeurs :
- Lucas
- Camille
- Chloé
- Noam
- Sami
- Alexandre
